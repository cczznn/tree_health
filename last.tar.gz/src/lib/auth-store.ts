const STORAGE_KEY = 'health_user'

export interface AuthUser {
  id: string
  name: string
  goalType: string
  age: number | null
  gender: 'male' | 'female' | null
  weight: number | null
  height: number | null
}

export function getStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function setStoredUser(user: AuthUser): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
}

export function clearStoredUser(): void {
  localStorage.removeItem(STORAGE_KEY)
}

export function getUserId(): string {
  return getStoredUser()?.id ?? ''
}

export function requireLogin(): boolean {
  if (!getStoredUser()) {
    // eslint-disable-next-line no-alert
    alert('请先登录后再操作')
    return false
  }
  return true
}

export function isLoggedIn(): boolean {
  return getStoredUser() !== null
}
