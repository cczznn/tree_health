# 工作记忆 - 健康管理小程序项目

## 项目概要
- 健康管理微信小程序，Node.js + TypeScript 后端，Taro + React 前端
- 数据库：MySQL 8.0（本地已安装），schema 在 src/db/schema.sql
- 自定义食物上限：50个/用户

## 已完成任务
- T1: 项目脚手架（Vitest + TypeScript + Express）
- T2: 数据模型、错误类型（NotFoundError/ValidationError/ConflictError）、仓储层（InMemoryRepository + FoodRepository）
- T3: 食物库与搜索 API（100种预置食物 + FoodService + Express路由），60个测试全绿

## 技术踩坑
- npm 缓存权限问题（Windows）：需用 `--cache ./.npm-cache` 参数绕过，用完删掉
- vitest 运行方式：`node ./node_modules/vitest/vitest.mjs run --reporter=verbose` 比 `npx vitest run` 更可靠（后者输出截断）
- 预置食物初始化需幂等（`initialized` 标志位）

## 项目目录结构
```
src/
  domain/     - types.ts, errors.ts, validation.ts
  repositories/ - index.ts (InMemoryRepository, FoodRepository)
  foods/      - preset-foods.ts (100种), food-service.ts
  api/        - foods.ts (Express路由)
  db/         - connection.ts, schema.sql
  app.ts      - Express应用
  index.ts    - 启动入口
tests/
  scaffold.test.ts, domain/validation.test.ts
  repositories/food-repository.test.ts
  foods/food-service.test.ts
  api/foods-api.test.ts
```
