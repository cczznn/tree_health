# AGENT_LOG.md

> 按时间顺序记录与 Superpowers / Cursor 协作完成本项目规约、计划与实现阶段的关键节点。

---

## 2026-05-23

### 1. 启动项目与读取课程要求
- **时间戳**：2026-05-23
- **任务编号**：无（项目启动）
- **阶段**：需求理解 / 项目启动
- **触发技能**：无（先完成文档理解）
- **关键上下文**：课程期末项目要求使用 Superpowers 完成规约驱动智能体开发，需要产出 `SPEC.md`、`PLAN.md`、`SPEC_PROCESS.md` 等文档。
- **动作**：读取课程说明文档，梳理项目要求，确认交付物与流程。
- **结果**：明确本项目不是单纯开发软件，而是要展示从需求到实现的完整 AI4SE 工程闭环。
- **学到的教训**：在开始写代码前，必须先把流程、文档和交付标准理解清楚，否则后面很容易返工。

### 2. 克隆 Superpowers 仓库并查看安装说明
- **时间戳**：2026-05-23
- **任务编号**：无（工具链准备）
- **阶段**：工具链准备
- **触发技能**：无（仓库安装准备）
- **关键上下文**：用户选择使用 Cursor，并希望把 Superpowers 作为 Cursor skills 使用。
- **动作**：克隆 `superpowers` 仓库，阅读安装文档与 Cursor 相关配置。
- **结果**：确认 Cursor 的安装方式是通过 `/add-plugin superpowers` 或插件市场安装。
- **学到的教训**：不同 agent/harness 的安装方式不同，不能把 OpenCode 的说明直接套到 Cursor 上。

### 3. 启动 brainstorming，收敛项目方向
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming
- **触发技能**：`brainstorming`
- **关键上下文**：项目起点为“健康、健身、饮食类小程序”，但范围模糊。
- **动作**：通过一系列问题澄清目标用户、使用场景、核心痛点、功能边界和最小可行版本。
- **结果**：项目收敛为一个面向大众通用用户的健康管理工具，核心问题聚焦为饮食摄入、饮食搭配与健身计划安排。
- **学到的教训**：如果不先明确用户与痛点，健康类项目会很容易泛化成没有主线的功能拼盘。

### 4. 决定引入 AI 推荐，并明确推荐边界
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 需求修订
- **触发技能**：`brainstorming`
- **关键上下文**：原先对 AI 推荐是否纳入核心范围并不确定。
- **动作**：在澄清需求过程中，决定保留 AI 推荐，但限制为“结构化规则 + LLM 文本生成”的混合方案，不做开放式聊天机器人。
- **结果**：AI 推荐被写入 `SPEC.md`，并明确了规则优先、LLM 负责组织文本、数据不足时降级为通用建议。
- **学到的教训**：推荐模块必须可控、可测，不能把“AI 功能”做成自由聊天问答。

### 5. 明确产品形态为微信小程序并加入底部 tab 栏
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 需求修订
- **触发技能**：`brainstorming`
- **关键上下文**：项目要最终上线到微信小程序，而不是仅仅做一个 Web 原型。
- **动作**：确认必须具备小程序布局感，并要求底部 tab 栏。
- **结果**：`SPEC.md` 中明确写入“最终上线到微信小程序”的目标，以及底部 tab 栏与小程序常见布局习惯。
- **学到的教训**：如果不把“最终交付形态”写死，前端任务很容易偏成普通 Web 界面。

### 6. 明确数据边界：登录、用户隔离、自定义食物私有化
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 需求修订
- **触发技能**：`brainstorming`
- **关键上下文**：健康、体重、饮食数据都属于个人私密数据。
- **动作**：决定需要登录与用户隔离，自定义食物仅属于对应用户，不与其他用户共享。
- **结果**：所有核心数据模型都增加 `userId` 维度，并把用户隔离写入 `SPEC.md`。
- **学到的教训**：健康类产品不能默认“单用户玩具化”，必须尽早考虑数据隔离。

### 7. 统一食物库搜索与来源策略
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 需求修订
- **触发技能**：`brainstorming`
- **关键上下文**：食物库中既有预置食物，也有用户自定义食物。
- **动作**：决定预置食物和自定义食物共享同一搜索接口，搜索结果默认不强制区分来源，但数据层保留来源字段。
- **结果**：`SPEC.md` 增加 `sourceType` 设计，并允许重名食物存在多个来源。
- **学到的教训**：前端体验要简洁，但后端数据层必须保留审计和区分能力。

### 8. 统一趋势视图为简单列表 + 最近变化值
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 需求修订
- **触发技能**：`brainstorming`
- **关键上下文**：体重 / 围度变化展示方式需要控制复杂度。
- **动作**：将趋势视图从复杂图表收敛为简单列表 + 最近变化值。
- **结果**：相关需求写入 `SPEC.md`，同时降低前端实现与测试难度。
- **学到的教训**：对于课程项目，能清楚表达变化趋势往往比复杂图表更重要。

### 9. 决定单仓库前后端分层与单容器优先策略
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：brainstorming / 技术边界修订
- **触发技能**：`brainstorming`
- **关键上下文**：项目需要兼顾课程交付节奏与后续部署。
- **动作**：确定采用单仓库前后端分层架构，并以单容器为主，只有确实拆分服务时才使用 docker-compose。
- **结果**：`SPEC.md` 的架构和容器化策略被显式写死。
- **学到的教训**：部署复杂度必须在一开始控制，否则后续会拖慢整个实现节奏。

### 10. 生成并整理 `PLAN.md`
- **时间戳**：2026-05-23
- **任务编号**：无（规约阶段）
- **阶段**：writing-plans
- **触发技能**：`writing-plans`
- **关键上下文**：`SPEC.md` 已确定主要功能、边界和产品形态。
- **动作**：将需求拆成 13 个可由单个 subagent 在一次会话中完成的任务，明确每个任务的目标、涉及文件、实现要点、验证步骤和依赖关系。
- **结果**：生成了覆盖基础工程、数据模型、食物库、饮食记录、统计、AI 推荐、前端、联调、容器化与 CI 的完整计划。
- **学到的教训**：任务拆分越清晰，后续 subagent 越不容易跑偏；每个任务必须先写失败测试。

### 11. 生成 `SPEC_PROCESS.md` 初稿
- **时间戳**：2026-05-23
- **任务编号**：无（文档沉淀）
- **阶段**：文档沉淀
- **触发技能**：无（由总结性写作完成）
- **关键上下文**：课程要求记录 brainstorming 与 plan 生成过程。
- **动作**：编写 `SPEC_PROCESS.md` 初稿，概述项目从模糊主题逐步收敛为明确方案的过程。
- **结果**：形成了一个结构化的过程文档初稿。
- **学到的教训**：过程文档不能只写结论，必须体现推理、迭代和决策依据。

### 12. 补强 `SPEC_PROCESS.md` 的对话节选与决策对照
- **时间戳**：2026-05-23
- **任务编号**：无（文档修订）
- **阶段**：文档修订
- **触发技能**：无（文档重写）
- **关键上下文**：作业要求明确写到“至少 3 轮关键迭代的对话节选”和“哪些建议是 AI 提出而你采纳/推翻的”。
- **动作**：补写 3 轮以上的关键迭代小节，加入对话节选风格的摘要，并增加 AI 建议 vs 人工决策的对照。
- **结果**：`SPEC_PROCESS.md` 更贴近课程 rubric，过程证据更完整。
- **学到的教训**：过程文档必须有“证据感”，否则很难体现你真实参与了需求收敛。

### 13. 调整前端技术选型为 Taro + TypeScript + React
- **时间戳**：2026-05-23
- **任务编号**：无（SPEC 修订）
- **阶段**：SPEC 修订
- **触发技能**：无（需求澄清）
- **关键上下文**：用户要求最终上线到微信小程序，并希望采用可编译到小程序的技术栈。
- **动作**：把 `SPEC.md` 里的前端选型从泛 Web/小程序风格表述，改为 `Taro + TypeScript + React`，并将相关描述调整为“基于 Taro 的小程序端界面，最终编译对齐微信小程序”。
- **结果**：技术选型与目标交付形态一致，不再是“像小程序的 Web”而是“可编译成小程序的前端”。
- **学到的教训**：技术选型必须与最终上线目标一致，否则文档会自相矛盾。

### 14. 调整数据库选型为 MySQL 或 SQLite
- **时间戳**：2026-05-23
- **任务编号**：无（SPEC 修订）
- **阶段**：SPEC 修订
- **触发技能**：无（需求澄清）
- **关键上下文**：用户当前没有安装 PostgreSQL，希望避免额外安装成本。
- **动作**：将 `SPEC.md` 中数据库选型改为 MySQL 或 SQLite，理由写明 SQLite 适合本地快速开发，MySQL 适合后续线上部署。
- **结果**：数据库选型更加贴近当前开发条件，也保留了后续迁移空间。
- **学到的教训**：选型不能只写“理想方案”，还要考虑当前环境与实现门槛。

---

## 2026-05-24

### 15. 继续审视 `SPEC.md` 与 `PLAN.md` 的一致性
- **时间戳**：2026-05-24
- **任务编号**：无（文档校对）
- **阶段**：文档校对
- **触发技能**：无
- **关键上下文**：用户开始检查 SPEC 的技术选型是否真的能支撑最终目标。
- **动作**：核对 `SPEC.md` 中前端、数据库、架构与 `PLAN.md` 任务拆分是否一致。
- **结果**：确认总体一致，主要修改集中在前端技术栈与数据库选型上。
- **学到的教训**：SPEC、PLAN、过程文档三者必须互相对齐，否则后续实现阶段会不断返工。

### 16. 形成当前的最终规约版本
- **时间戳**：2026-05-24
- **任务编号**：无（规约定稿）
- **阶段**：规约定稿
- **触发技能**：无
- **关键上下文**：需要将所有关键决策写成可执行、可验收的最终版文档。
- **动作**：整理并确认当前版 `SPEC.md`、`PLAN.md` 与 `SPEC_PROCESS.md` 的一致性。
- **结果**：规约层文档已基本可作为后续实现的稳定基线。
- **学到的教训**：在进入实现前，规约层越稳定，后续的 TDD 和 subagent 开发越顺利。

冷启动workbuddy部分：
----------------------------------------------------------------------------
## 2026-05-23（实现阶段）
### 1. T1：项目脚手架搭建
- **时间戳**：2026-05-23
- **阶段**：T1 实现
- **关键上下文**：项目从零开始，需建立可运行、可测试的工程基础。
- **动作**：初始化 Node.js + TypeScript 项目，配置 Vitest 测试框架、ESLint，创建 src/ 与 
tests/ 目录结构，编写脚手架验证测试。
- **结果**：2 个验证测试通过，TypeScript + Vitest 运行正常。
- **学到的教训**：npm 缓存权限问题（Windows）需要用 `--cache ./.npm-cache` 参数绕过。
### 2. T2：数据模型、错误类型与仓储层
- **时间戳**：2026-05-23
- **阶段**：T2 实现
- **触发技能**：无
- **关键上下文**：所有业务模块依赖统一的类型定义、校验规则和仓储接口。
  - 定义 User、Food、MealRecord、WorkoutPlan、WorkoutCheckin、BodyMetric、Recommendation 
  共 
  7 个核心实体类型。
  - 实现 NotFoundError、ValidationError、ConflictError 统一错误类型。
  - 实现 validateFood、validateBodyMetric、validateMealRecord 校验函数。
  - 实现通用 InMemoryRepository 和 FoodRepository（含搜索、配额统计）。
- **结果**：32 个测试全绿（校验 18 + 仓储 14）。
- **学到的教训**：仓储接口先做内存版，后续可无缝替换为 MySQL 实现，不影响业务逻辑和测试。
### 3. T3：食物库与搜索 API
- **时间戳**：2026-05-23
- **阶段**：T3 实现
- **触发技能**：无
- **关键上下文**：食物库是核心模块之一，需支持预置食物搜索、详情查询、自定义食物创建及配额限制。
  - 编写 100 种中国常见食物的预置数据集（覆盖主食、肉禽蛋、水产海鲜、蔬菜、豆制品、水果、奶制品
  饮
  品）。
  - 实现 FoodService 服务层（搜索、详情、自定义食物创建、配额限制 50/用户）。
  - 创建 MySQL 数据库 schema（7 张表）和连接池工具。
  - 实现 Express API 路由（GET/POST /foods）。
  - 编写食物服务测试（15 个）和 API 集成测试（11 个）。
- **结果**：全量 60 个测试通过（5 个测试文件），食物搜索、详情、自定义创建、配额限制全部验收通
过。
  - 预置食物的初始化需要幂等设计（`initialized` 标志位），避免重复加载。
  - API 路由测试使用 supertest 可以直接测试 Express 应用，不需要真正启动服务器。
  - 自定义食物的可见性逻辑（仅创建者可见）必须在仓储层的搜索方法中实现，而非在 API 层。
-----------------------------------------------------------------------

### 17. T1 冷启动实现：脚手架与测试框架
- **时间戳**：2026-05-24
- **任务编号**：T1
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`
- **关键上下文**：按照实验要求，先在独立 worktree 中实现 T1，并确保先有失败测试，再最小实现，再验证。
- **动作**：
  - 使用 `git worktree add ../last-t1 -b feature/t1-scaffold` 创建独立工作区
  - 先补充 `vitest.config.ts` 与 `tests/scaffold.test.ts`
  - 首次运行测试时发现缺少依赖 / 默认 npm cache 目录权限问题
  - 通过设置项目内 cache 后执行 `npm install`
  - 再次运行 `npm test`，确认测试通过
- **结果**：T1 脚手架可运行，Vitest 已经能正常执行，基础测试命令通过。
- **学到的教训**：
  - Windows 环境下默认 npm cache 路径可能触发权限问题，最好尽早把 cache 放到项目内
  - T1 的核心不是“写很多代码”，而是先把测试框架和最小验证链路打通
  - worktree 隔离很适合后续并行任务，但前提是每个 worktree 都有清晰的任务边界

### 18. T2 冷启动实现：数据模型、错误类型与仓储层
- **时间戳**：2026-05-24
- **任务编号**：T2
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T2 需要继承 T1 的脚手架，在最新 `master` 基线下重新创建干净 worktree，并先写失败测试再补最小实现。
- **动作**：
  - 删除旧的 `feature/t2-domain-repo` 关联，基于最新 `master` 重新创建 `last-t2` worktree
  - 先写 `tests/domain/validation.test.ts` 与 `tests/repositories/food-repository.test.ts`
  - 补齐 `src/domain/errors.ts`、`src/domain/types.ts`、`src/domain/validation.ts`、`src/foods/preset-foods.ts`、`src/repositories/index.ts`
  - 多轮运行 `npm test`，修复预置食物数量不达标、重复导出、数量超出目标等红灯
  - 最终将预置食物数据精确调整为 100 条，验证 T2 相关测试全绿
- **结果**：T2 的领域模型、错误类型、校验规则、内存仓储与预置食物数据已落地，相关测试全绿，满足后续 T3/T4/T7/T9 的基础依赖。
- **学到的教训**：
  - 冷启动验证暴露出“预置数据规模”必须写死，否则陌生智能体会卡住
  - 先写测试能快速暴露实现边界问题，尤其是数据条数和导出重复这类细节
  - worktree 从最新 master 重建能显著降低历史脏状态带来的干扰

### 19. T3 冷启动实现：食物库与搜索 API
- **时间戳**：2026-05-24
- **任务编号**：T3
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T3 需要在最新 `master` 上重新创建干净 worktree，并先写食物搜索、详情、自定义创建与 API 的失败测试，再补最小实现。
- **动作**：
  - 删除旧的 `feature/t3-food-search` 关联，基于最新 `master` 重新创建 `last-t3` worktree
  - 先写 `tests/foods/food-service.test.ts`、`tests/repositories/food-repository.test.ts`、`tests/api/foods-api.test.ts`
  - 补齐 `src/foods/food-service.ts`、`src/api/foods.ts`、`src/repositories/index.ts` 与预置食物初始化逻辑
  - 多轮运行 `npm test`，修复 `validInput` 作用域问题与实现缺失带来的红灯
  - 验证搜索、详情、自定义创建、配额限制、预置食物数量与可见性规则均通过
- **结果**：T3 的食物搜索 API、服务层、自定义创建与 API 集成测试全部通过，满足后续 T4/T5/T6 的依赖前提。
- **学到的教训**：
  - 测试作用域问题会伪装成实现问题，先读报错再改代码很重要
  - 预置数据和仓储初始化必须一致，否则 API/服务/仓储三层测试会同时报警
  - worktree 基线对齐后，TDD 定位会更清晰，避免旧分支状态干扰

### 20. T4 冷启动实现：饮食记录 CRUD 与日汇总
- **时间戳**：2026-05-24
- **任务编号**：T4
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T4 要实现饮食记录新增、编辑、删除、按日查询，以及独立持久化日汇总；用户明确要求新增增量、编辑/删除整天重算。
- **动作**：
  - 基于当前 `master` 创建 `last-t4` 独立 worktree 和 `feature/t4-meal-records` 分支
  - 先写 `tests/meal-records/meal-record-service.test.ts` 和 `tests/api/meal-records-api.test.ts`
  - 补齐 `DailyMealSummary`、`MealRecordRepository`、`DailyMealSummaryRepository`、`MealRecordService` 与 `src/api/meal-records.ts`
  - 在红灯阶段逐步修复：缺失模块、用户隔离、日期必填、自定义食物归属、日期变更重算等边界
  - 最终 `npm test` 通过，T4 的主路径与边界场景都变绿
- **结果**：T4 完成，日汇总独立持久化且支持混合更新策略；相关测试全绿。
- **学到的教训**：
  - 记录变更与汇总更新最好在服务层统一编排，不要散落在 API 层
  - 编辑改日期是一个容易漏掉的边界，必须显式测试
  - 用户隔离与详情可见性最好从一开始就写入 API / service，而不是后补

### 21. T4 之后的代码自检与边界补强
- **时间戳**：2026-05-24
- **任务编号**：T4（收尾）
- **阶段**：代码自检 / 边界修正
- **触发技能**：`systematic-debugging`、`test-driven-development`
- **关键上下文**：用户要求对 T4 进行额外代码自检与边界梳理。
- **动作**：
  - 检查 `MealRecordService`、`FoodRepository`、`FoodService`、`api` 层与相关测试
  - 发现并补强用户隔离、日期必填、自定义食物归属检查、日期变更重算等边界
  - 追加测试覆盖：查看/修改/删除他人记录、缺少日期参数、改日期后旧新汇总同步
- **结果**：T4 边界场景补齐，测试集合扩大且依然保持全绿。
- **学到的教训**：功能主流程绿灯并不代表边界稳固；额外自检能有效把“看起来能用”变成“真的合规”。

### 22. 清理剩余 TypeScript typecheck 报错
- **时间戳**：2026-05-24
- **任务编号**：T4（工程质量收尾）
- **阶段**：类型修复 / 验证
- **触发技能**：`systematic-debugging`
- **关键上下文**：运行 `npm run typecheck` 后暴露出 Node、Express、Supertest、query 参数和 `validateMealRecord` 的类型报错。
- **动作**：
  - 安装并启用 `@types/node`、`@types/express`、`@types/supertest`
  - 调整 `tsconfig.json` 的 `types` 为 `vitest/globals` + `node`
  - 修正 `validateMealRecord` 的类型定义，使其支持测试与服务层的调用方式
  - 修正 API 层 query / params 的类型处理
  - 修正 `MealRecordService` 中日期类型推断问题
- **结果**：`npm run typecheck` 最终通过，项目类型错误清零。
- **学到的教训**：测试能过不代表类型系统健康；在 TypeScript 项目里，`typecheck` 是独立且必须过的一道关。

### 23. 按课程要求回写 `PLAN.md` 与 `AGENT_LOG.md`
- **时间戳**：2026-05-24
- **任务编号**：T4（文档同步）
- **阶段**：文档同步
- **触发技能**：无（按课程要求整理实现记录）
- **关键上下文**：课程要求 `PLAN.md` 持续更新，并维护完整的 `AGENT_LOG.md` 过程记录。
- **动作**：
  - 将 `PLAN.md` 的 `T3`/`T4` 结果记录更新为实际完成状态与 commit hash
  - 把 T4 的独立持久化日汇总策略写入计划文档
  - 在 `AGENT_LOG.md` 中追加 T4 实现、边界修正与 typecheck 收敛的记录
- **结果**：计划文档与实现状态保持一致，过程日志更完整。
- **学到的教训**：文档不是“做完之后随便补”，而是实现过程的一部分；持续同步能减少最终整理成本。

### 24. 文档版本提交到 `master`
- **时间戳**：2026-05-24
- **任务编号**：无（文档同步）
- **阶段**：文档提交
- **触发技能**：无
- **关键上下文**：用户要求把 `last` 目录下文档修改提交到 `master`，以便后续在对应 worktree 内减少额外提交次数。
- **动作**：将 `PLAN.md`、`AGENT_LOG.md` 和 `SPEC_PROCESS.md` 的更新统一提交到本地 `master`。
- **结果**：本地 `master` 获得文档同步提交，后续可基于更干净的基线创建新 worktree。
- **学到的教训**：把文档同步到主干，可以让后续任务 worktree 的上下文更稳定，也更容易减少重复提交。

### 25. 同步本地 `master` 与远端最新状态
- **时间戳**：2026-05-24
- **任务编号**：无（仓库同步）
- **阶段**：仓库同步
- **触发技能**：无
- **关键上下文**：需要确保后续新建任务 worktree 时，基线与远端一致。
- **动作**：执行远端同步操作，使本地 `master` 与远端最新提交保持一致。
- **结果**：本地 `master` 已同步到远端最新状态，可直接作为后续 `T5` 的基线。
- **学到的教训**：在新任务前先同步基线，可以减少“本地和远端不一致”导致的分叉问题。

### 26. T5 冷启动实现：单日热量 / 营养素统计与目标对比
- **时间戳**：2026-05-25
- **任务编号**：T5
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T5 只做“某一天”的统计口径，要求在独立 `last-t5` worktree 中先写失败测试，再实现单日统计、空状态和简单目标对比。
- **动作**：
  - 创建 `last-t5` worktree 并以 `feature/t5-daily-stats` 分支推进
  - 先写 `tests/stats/daily-stats-service.test.ts` 与 `tests/api/stats-api.test.ts`
  - 补齐 `src/stats/daily-stats-service.ts`、`src/api/stats.ts`
  - 复用 `meal-records` 的共享上下文，确保统计和记录使用同一数据源
  - 通过多轮修正让 `npm test` 与 `npm run typecheck` 都通过
- **结果**：T5 单日统计能力落地，测试与类型检查均通过。
- **学到的教训**：统计类能力最好从“单日闭环”开始，否则很容易在范围上失控；共享上下文必须重置，否则测试之间会相互污染。

### 27. T5 完成后的问题修复与上下文隔离
- **时间戳**：2026-05-25
- **任务编号**：T5（收尾）
- **阶段**：代码修正 / 边界补强
- **触发技能**：`systematic-debugging`
- **关键上下文**：T5 在集成测试中暴露了共享上下文污染与目标对比字段缺失问题。
- **动作**：
  - 将 `app-context` 改为可重置的 `beginNewAppContext()` 机制
  - 为 `meal-records` 与 `stats` API 统一切换到同一上下文
  - 为统计结果补充 `goalComparison`，并修复日期 / 用户头的边界处理
- **结果**：统计与记录在测试中稳定共享同一数据源，T5 相关测试最终全部通过。
- **学到的教训**：状态型内存仓储在测试环境中一定要可重置，否则集成测试会出现难以定位的串扰问题。

### 28. T6 冷启动设计与确认：自定义食物创建规则收敛
- **时间戳**：2026-05-25
- **任务编号**：T6（设计阶段）
- **阶段**：brainstorming / 需求澄清
- **触发技能**：`brainstorming`
- **关键上下文**：用户要求实现 T6，并明确希望在 `E:\6\ai\last-t6` worktree 中完成，同时要遵循课程文档第 131–139 行对 T6 的要求。
- **动作**：
  - 先确认“自定义食物创建后必须立刻出现在搜索里，且允许同名”
  - 进一步确认字段策略后，用户决定：`name + calories + protein + fat + carbs` 必填，`fiber / sugar / sodium` 可选
  - 讨论后确定可选营养字段应以 `null` 语义保存，而不是默认补 0
  - 将设计收敛为：创建后立即可搜、允许同名、用户隔离不变、可选字段兼容空值
- **结果**：T6 的输入规则和数据语义已明确，不再沿用 SPEC 中“全字段必填”的更严格版本。
- **学到的教训**：当课程 SPEC 与实际产品决策不完全一致时，必须把最终采用的规则显式写下来，不能默认实现者自行猜测。

### 29. T6 实现：自定义食物创建与搜索联动
- **时间戳**：2026-05-25
- **任务编号**：T6
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T6 需要在 `E:\6\ai\last-t6` 中完成，且要保留与 T3/T4/T5 一致的用户隔离、搜索联动和 API 行为。
- **动作**：
  - 检查 `last-t6` worktree 与已有代码状态
  - 读取 `src/domain/types.ts`、`src/domain/validation.ts`、`src/foods/food-service.ts`、`src/repositories/index.ts`、`src/api/foods.ts`、`tests/api/foods-api.test.ts`
  - 将 `CreateCustomFoodInputDTO` 的可选字段调整为 `fiber/sugar/sodium?: number | null`
  - 把 `validateFood` 扩展为允许可选字段为 `null`
  - 在 `FoodService.createCustomFood()` 中将缺失的可选字段落库为 `null`
  - 将 API 测试里的创建请求 body 调整为只传必填字段，确保兼容简化输入规则
  - 运行 `npm install` 补齐 `last-t6` worktree 的依赖后，再执行 `npm run typecheck` 与 `npm test`
- **结果**：T6 的自定义食物创建能力已实现，创建后能立即进入搜索结果，且允许同名；类型检查和测试均通过。
- **学到的教训**：
  - 课程文档中的规范不一定是最终产品规则，必须以用户确认的方案为准
  - 可选字段最好在类型层、校验层、服务层一起调整，否则很容易出现“类型过了但运行时不兼容”
  - 在独立 worktree 中实现任务时，先补依赖再验收能减少环境问题对判断的干扰

### 30. T7 需求确认：最小输入与实现边界收敛
- **时间戳**：2026-05-25
- **任务编号**：T7（设计阶段）
- **阶段**：brainstorming / 需求澄清
- **触发技能**：`brainstorming`
- **关键上下文**：用户要求在 `last-t7` worktree 中推进 T7，并先确认训练计划的最小输入。
- **动作**：
  - 确认 T7 输入采用“目标类型 + 每周训练频率”
  - 讨论并选择了规则模板生成方案，避免引入自由生成带来的不稳定性
  - 收敛出按目标分类、按频率展开训练日程的实现边界
- **结果**：T7 的输入与输出边界已经明确，可开始 TDD 实现。
- **学到的教训**：训练计划这种模块如果输入过多，容易让任务范围失控；先用最小输入把规则跑通最稳妥。

### 31. T7 实现：健身计划模板与生成
- **时间戳**：2026-05-25
- **任务编号**：T7
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T7 要在独立 `last-t7` worktree 中实现，先写失败测试，再补模板服务，最后验证类型与测试。
- **动作**：
  - 创建 `feature/t7-workout-plans` worktree
  - 先写 `tests/workout-plans/workout-plan-service.test.ts`
  - 新增 `src/workout-plans/workout-plan-service.ts`
  - 通过规则模板根据 `goalType + frequencyPerWeek` 生成不同训练安排
  - 修复类型与断言问题后，使 `npm run typecheck` 与 `npm test` 均通过
- **结果**：T7 的健身计划模板与生成能力已完成，输出结构化训练计划，可供后续打卡模块引用。
- **学到的教训**：模板驱动比自由生成更稳定，也更适合课程项目的可验证要求；测试里应该明确断言输出结构，而不仅是标题文本。

### 32. T8 需求确认：打卡策略与绑定粒度收敛
- **时间戳**：2026-05-25
- **任务编号**：T8（设计阶段）
- **阶段**：brainstorming / 需求澄清
- **触发技能**：`brainstorming`
- **关键上下文**：用户要求在 `last-t8` worktree 中推进 T8，并先确认重复打卡策略与绑定粒度。
- **动作**：
  - 确认同一天允许多次提交，按时间顺序保留多条记录
  - 确认打卡绑定粒度为 `planId + date + note`
  - 收敛出轻量记录型打卡模型，不做动作级唯一性限制
- **结果**：T8 的输入与查询规则已经明确，可开始 TDD 实现。
- **学到的教训**：打卡功能如果过早引入唯一性约束，会直接和“保留历史”目标冲突；先保留多条记录最稳妥。

### 33. T8 实现：运动打卡与按日查询
- **时间戳**：2026-05-25
- **任务编号**：T8
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T8 需要在独立 `last-t8` worktree 中实现，先写失败测试，再补打卡服务与仓储支持，最后验证类型与测试。
- **动作**：
  - 创建 `feature/t8-checkins` worktree
  - 新增 `src/workout-checkins/workout-checkin-service.ts`
  - 增补 `WorkoutPlanRepository` 与 `WorkoutCheckinRepository`
  - 先写 `tests/workout-checkins/workout-checkin-service.test.ts`
  - 按 `planId + date` 查询当天全部打卡记录，同一天重复提交保留历史
  - 运行 `npm run typecheck` 与 `npm test`
- **结果**：T8 的运动打卡与查询能力已完成，测试与类型检查均通过。
- **学到的教训**：只要把“创建”和“查询”两条主路径打通，打卡功能就能形成稳定闭环；重复提交不要在仓储层偷偷覆盖。

### 34. T9 冷启动设计与确认：记录型 CRUD + 简单趋势函数
- **时间戳**：2026-05-25
- **任务编号**：T9（设计阶段）
- **阶段**：brainstorming / 需求澄清
- **触发技能**：`brainstorming`
- **关键上下文**：用户要求在 `last-t9` worktree 中推进 T9，并确认最小输入与趋势输出方式。
- **动作**：
  - 确认 T9 最小输入采用 `metricDate + weight`，围度可选
  - 选择“记录型 CRUD + 简单趋势函数”方案
  - 收敛出 `latest / previous / delta / direction` 的轻量趋势结构
- **结果**：T9 的输入与趋势边界已经明确，可开始 TDD 实现。
- **学到的教训**：体重与围度记录最重要的是稳定保存和清晰趋势，不必一开始就做复杂图表或体型分析。

### 35. T9 实现：体重 / 围度记录与趋势
- **时间戳**：2026-05-25
- **任务编号**：T9
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T9 需要在独立 `last-t9` worktree 中实现，先写失败测试，再补身体数据仓储和趋势函数，最后验证类型与测试。
- **动作**：
  - 创建 `feature/t9-body-metrics` worktree
  - 新增 `src/body-metrics/body-metric-service.ts`
  - 增补 `BodyMetricRepository`
  - 先写 `tests/body-metrics/body-metric-service.test.ts`
  - 实现保存、按日期范围查询、趋势函数与边界校验
  - 运行 `npm run typecheck` 与 `npm test`
- **结果**：T9 的体重 / 围度记录与趋势输出能力已完成，测试与类型检查均通过。
- **学到的教训**：趋势函数本质上是可测试的纯逻辑，应该尽量与持久化分离，方便后续扩展和前端展示。

### 36. T10 冷启动设计：规则引擎 + 模板化文案
- **时间戳**：2026-05-25
- **任务编号**：T10（设计阶段）
- **阶段**：brainstorming / 需求澄清
- **触发技能**：`brainstorming`
- **关键上下文**：用户要求在 `last-t10` worktree 中推进 T10，并选择方案 B：规则引擎 + 模板化文案，输入最小依赖为饮食统计、健身计划、体重趋势和用户目标信息。
- **动作**：
  - 确认推荐不是自由聊天，而是结构化建议生成
  - 讨论并采用规则 + 模板输出，而不是可选 LLM 包装
  - 收敛出推荐输出的结构化字段与回退策略
  - 明确本任务只做单轮结构化推荐，不引入长期记忆或医疗建议
- **结果**：T10 的输入与输出边界已明确，可开始进入实现阶段。
- **学到的教训**：AI 推荐如果没有结构化输入和稳定模板，很容易从“推荐”变成“不可控文本生成”；课程项目里稳定性优先。

### 37. T10 实现：结构化推荐与降级策略
- **时间戳**：2026-05-25
- **任务编号**：T10
- **阶段**：实现 / TDD / worktree 隔离
- **触发技能**：`test-driven-development`、`subagent-driven-development`、`systematic-debugging`
- **关键上下文**：T10 需要在独立 `last-t10` worktree 中实现，并把“饮食统计、健身计划、体重趋势、用户目标信息”整合成一轮可解释推荐。
- **动作**：
  - 新增 `RecommendationService` 与对应测试骨架
  - 设计结构化推荐输出，采用原因 + 建议的形式
  - 为数据不足场景加入降级建议
  - 通过类型检查与测试验证实现稳定性
- **结果**：T10 的基础推荐生成能力已完成，输出结构化、可解释且可降级。
- **学到的教训**：把推荐拆成规则判断和模板文案后，测试会更清晰，输出也更适合前端消费。

### 38. T11 预处理：在前端 worktree 中修复后端审查问题
- **时间戳**：2026-05-26
- **任务编号**：T11（预处理）
- **阶段**：代码修复 / 收尾整理
- **触发技能**：`receiving-code-review`、`systematic-debugging`
- **关键上下文**：在进入 T11 前端页面开发前，先处理 `last-t11` worktree 中审查出的后端实现问题，避免后续页面联调用到带缺陷的基础能力。
- **动作**：
  - 修复 `MealRecordService` 中更新/重算逻辑里残留的 `as any`
  - 调整 `rebuildSummary` 的空状态语义，避免删除最后一条记录后返回含混的汇总对象
  - 将仓储层 `getById` 的错误实体名改为具体实体名，提升错误可读性
  - 统一处理 `x-user-id` 相关的缺失判断思路，并为 `WorkoutCheckin` 增加 `createdAt`
  - 运行 `npm test` 与 `npm run typecheck` 验证修复结果
- **结果**：T11 worktree 的基础后端能力已收敛，测试和类型检查通过，可继续进行前端骨架实现。
- **学到的教训**：前端开发前先把底层数据与错误语义修稳，能显著减少联调阶段的噪音和返工。

### 39. T11 环境修复：解决微信小程序空白页面问题
- **时间戳**：2026-05-27
- **任务编号**：T11（环境修复）
- **阶段**：调试 / 问题定位
- **触发技能**：`systematic-debugging`
- **关键上下文**：Taro 编译后在微信开发者工具中打开，所有页面内容空白，仅底部 tab 栏正常显示。
- **动作**：
  - 检查微信开发者工具控制台，发现 `ReferenceError: React is not defined`
  - 排查发现 JSX 编译为 `React.createElement` 全局调用，但 webpack ProvidePlugin 未生效
  - `babel.config.cjs` 中 `@babel/preset-react` 改为 `{ runtime: 'automatic' }`，JSX 编译产物从 `React.createElement` 变为 `react/jsx-runtime` 的 `jsx/jsxs`
  - `config/index.ts` 中显式添加 `plugins: ['@tarojs/plugin-framework-react']`
  - 删除多余的 `src/main.tsx`（Taro 不需要 `createRoot` + `document.getElementById`）
  - CSS 引入从 `main.tsx` 移至 `app.tsx`
- **结果**：重新编译后页面内容正常显示，5 个 tab 页均可渲染。
- **学到的教训**：
  - `@babel/preset-react` 的 `runtime: 'automatic'` 是 Taro 4.x 微信小程序编译的关键配置
  - 微信小程序不支持 `gap` CSS 属性，需用 `margin-right` 替代
  - CSS 类和 `var()` 变量在小程序中兼容性差，内联 style + 硬编码颜色值是最可靠的方式

### 40. T11 实现：首页与饮食记录页
- **时间戳**：2026-05-27
- **任务编号**：T11（首页 + 饮食页）
- **阶段**：实现 / TDD
- **触发技能**：`test-driven-development`、`subagent-driven-development`
- **关键上下文**：先写 `lib/api.ts`、`lib/page-data.ts`、`lib/food-search.ts`、`lib/meal-form.ts` 的单元测试，再实现页面组件。
- **动作**：
  - 重写 `lib/api.ts`：去掉 `fetch()`（小程序不支持），替换为内嵌 mock 数据（3 条饮食记录 + 12 种食物 + 健身计划）
  - 提取 `buildHomeDisplay` / `buildDietDisplay` 纯函数到 `lib/page-data.ts`，覆盖加载态、错误态、数据态
  - 提取 `filterFoods` / `formatCalories` 到 `lib/food-search.ts`
  - 提取 `validateMealForm` / `getMealTypeLabel` 到 `lib/meal-form.ts`
  - 先写 18 个测试（`tests/lib/api.test.ts`、`page-data.test.ts`、`food-search.test.ts`、`meal-form.test.ts`），全部通过后再实现页面
  - 实现首页：`useEffect` 加载数据 → `buildHomeDisplay` 转换 → 渲染 kcal/记录数/饮食摘要/计划摘要
  - 实现饮食页：搜索框 → 搜索结果列表 → 点击"+ 记录" → 表单（份量 + 餐次标签 + 确认/取消按钮）→ 添加后实时更新今日汇总
- **结果**：
  - 首页正常显示今日概览和摘要
  - 饮食页"搜索→选择→记录"完整链路可用
  - 测试从 80 个增长到 111 个，全部通过
- **学到的教训**：
  - 把数据转换逻辑提取为纯函数，可以在不依赖 Taro 运行时的情况下写测试
  - 微信小程序 `Input` 的 `onInput` 回调用 `e.detail.value` 取值，不是 `e.target.value`
  - 表单按钮用内联 style 而非 CSS 类，避免小程序样式不生效

### 41. T11 实现：计划页、身体页、我的页
- **时间戳**：2026-05-27
- **任务编号**：T11（计划页 + 身体页 + 我的页）
- **阶段**：实现 / TDD
- **触发技能**：`test-driven-development`、`subagent-driven-development`
- **关键上下文**：完成剩余页面，保持与饮食页一致的交互模式（内联 style、mock API、表单验证）。
- **动作**：
  - 计划页：展示训练计划 + 周安排列表 + 打卡按钮 → 打卡表单 → 打卡历史
  - 身体页：提取 `validateBodyForm` / `computeTrend` 到 `lib/body-data.ts`，先写 8 个测试 → 实现体重/围度记录展示 + 趋势计算 + 添加表单
  - 我的页：目标设置（减脂/维持/增肌）可点击切换，内联 style 实现选中态
  - 在 `lib/api.ts` 中添加 `getBodyMetrics`、`addBodyMetric`、`getWorkoutCheckins`、`addWorkoutCheckin` mock API
- **结果**：
  - 5 个 tab 页全部完成，所有交互可用
  - 测试增长到 119 个，18 个测试文件全绿
  - typecheck 通过，构建成功
- **学到的教训**：
  - 身体数据趋势计算是纯逻辑，应尽量与 UI 分离，方便测试和复用
  - 小程序中 CSS 类名方案在 WeChat 工具中不稳定，全项目统一采用内联 style + 硬编码颜色值
  - 本地添加的数据需要与 mock API 数据合并显示（如饮食汇总 = mock 3 条 + 本地添加 N 条），否则用户会困惑

### 42. T11 收尾：目标设置交互修复
- **时间戳**：2026-05-27
- **任务编号**：T11（收尾）
- **阶段**：UI 修复
- **触发技能**：`systematic-debugging`
- **关键上下文**：用户反馈目标设置标签点击后文字消失、无边框中。
- **动作**：
  - 将目标标签从 CSS 类改为内联 style
  - 选中态：绿色背景 `#07c160` + 白字 + 绿色边框
  - 未选中态：白色背景 + 灰色边框 `#d1d5db` + 深灰文字 `#374151`
- **结果**：目标标签可正常点击切换，选中态文字清晰可见。
- **学到的教训**：WeChat 小程序 CSS 类可靠性低于内联 style，全项目应保持一致的内联 style 策略。

### 43. T12 环境搭建：创建 worktree 与 H5 构建配置

- **时间戳**：2026-05-27
- **任务编号**：T12（环境搭建）
- **阶段**：环境搭建 / 问题定位
- **触发技能**：`systematic-debugging`
- **关键上下文**：基于最新 master 创建 `feature/t12-e2e-integration` worktree，完成 H5 模式的前后端联调环境搭建。
- **动作**：
  - `git worktree add ../last-t12 -b feature/t12-e2e-integration`，安装依赖（使用 `--legacy-peer-deps` + 项目内 `.npm-cache`）
  - 安装 `@tarojs/plugin-platform-h5`、`tsx` 等 H5 构建所需依赖
  - 修复 Taro 4.2 H5 构建报错：`prebundle` 需配置为 `compiler: { prebundle: { enable: false } }`
  - 创建 `src/index.html` 作为 H5 模板
- **结果**：`npm run build:h5` 构建成功，`dist/` 输出 H5 静态文件。
- **学到的教训**：
  - Taro 4.x H5 构建需要显式安装 `@tarojs/plugin-platform-h5`，不是内置的
  - `compiler.prebundle` 必须显式配置，否则 webpack5-runner 内部报 undefined

### 44. T12 实现：Express Server 入口与缺失路由

- **时间戳**：2026-05-27
- **任务编号**：T12（Express Server）
- **阶段**：实现 / TDD
- **触发技能**：`test-driven-development`
- **关键上下文**：项目已有 Express 路由处理器（`src/api/`），但缺少 server 入口和 workout-checkins、body-metrics、recommendations 三个 API 路由。
- **动作**：
  - 新建 `src/server.ts`：创建 Express app → 挂载 7 个 API 路由 → health check → serve `dist/` 静态文件
  - 新建 `src/api/workout-checkins.ts`：GET/POST 打卡接口
  - 新建 `src/api/body-metrics.ts`：GET/POST 身体数据接口
  - 新建 `src/api/recommendations.ts`：POST 推荐生成接口
  - 更新 `src/app-context.ts`：增加 `workoutPlanRepo`、`workoutCheckinRepo`、`bodyMetricRepo`
  - 修复多个 Express 5 兼容问题：`app.get('*')` → `app.use()`、`__dirname` 在 ESM 中不可用 → `fileURLToPath`
  - 修复 `src/api/foods.ts`：使用共享 `foodRepo`（`getAppContext()`），而非新建空 `FoodRepository`
- **结果**：
  - `npx tsx src/server.ts` 启动成功，`curl /api/health` 返回 200
  - 所有 API 端点可通过 curl 验证：foods、meal-records、stats、workout-plans、workout-checkins、body-metrics、recommendations
  - H5 前端文件正常 serve，浏览器打开 `http://localhost:3000` 展示完整页面
- **学到的教训**：
  - Express 5 的 path-to-regexp 不支持 `*` 通配符，需改用 `app.use()` 做 SPA fallback
  - `package.json` 中 `"type": "module"` 导致 `__dirname` 不可用，需 `fileURLToPath(import.meta.url)`

### 45. T12 实现：前后端数据格式对齐

- **时间戳**：2026-05-27
- **任务编号**：T12（格式对齐）
- **阶段**：实现 / 联调
- **触发技能**：`systematic-debugging`
- **关键上下文**：T11 前端使用 mock 数据时的格式与后端实际返回格式不匹配，需统一。
- **动作**：
  - 删除 `lib/api.ts` 中所有 mock 数据，替换为 `fetch()` 调用真实 API
  - 修复 stats API 返回格式：从嵌套 `{ data: { summary: { ... } } }` 改为扁平 `{ data: { mealCount, totalCalories, ... } }`
  - 修复 meal-records API：无记录时返回零值 `summary` 而非 `null`，避免前端崩溃
  - 修复 body-metrics API：`getTrend` 无数据时返回 `null` 而非抛错
  - 修复 workout-checkin：`note` 改为可选（前端允许空备注）
  - 修复 body metrics POST：自动补 `metricDate` 默认值（今天）
  - 更新 `tests/lib/api.test.ts`：mock 数据测试改为 mock fetch 测试
  - 更新 `tests/api/stats-api.test.ts`、`meal-records-api.test.ts`：适配新返回格式
- **结果**：
  - 前端页面正常加载数据，首页显示 kcal/记录数/饮食摘要/计划摘要
  - 饮食、计划、身体、我的四个 tab 页均可正常交互
  - 113 个测试全部通过
- **学到的教训**：
  - SPEC 定义的 API 格式与实际实现必须逐字段对齐，否则前端反序列化会静默失败
  - 无数据时返回零值对象比 `null` 更安全，省去前端大量判空逻辑

### 46. T12 实现：内存数据预置与启动流程

- **时间戳**：2026-05-27
- **任务编号**：T12（内存预置）
- **阶段**：实现
- **触发技能**：`systematic-debugging`
- **关键上下文**：启动 server 后页面显示"数据加载失败"，排查发现 in-memory repository 中没有预置 workout plan，导致 workout-checkins API 返回 404。
- **动作**：
  - `app-context.ts` 中 `beginNewAppContext()` 同步预置默认 workout plan（`wp-1`）
  - `server.ts` 中数据库初始化改为 `dynamic import` + `Promise.race` 3 秒超时，MySQL 不可用时回退内存模式
  - `server.ts` 添加请求日志中间件，方便调试
- **结果**：
  - 无需 MySQL 即可直接运行 `npx tsx src/server.ts`，3 秒内启动完成
  - 100 条预置食物 + 默认健身计划就绪，所有 API 可正常响应
  - 终端打印每次请求的 method/url，便于验证
- **学到的教训**：
  - 无数据库环境下的 fallback 机制是开发体验的关键
  - 动态 import + 超时可以优雅处理可选依赖不可用的情况

### 47. T12 实现：营养素完整记录与展示

- **时间戳**：2026-05-27
- **任务编号**：T12（营养素展示）
- **阶段**：功能增强 / 联调完善
- **触发技能**：`test-driven-development`
- **关键上下文**：用户反馈添加白米饭(100g)后蛋白质显示 20g 而非 2.6g，排查发现本地 meal 未存储真实营养素值，蛋白质用 `calories × 0.17` 估算。
- **动作**：
  - 扩展 `FoodItem` 类型：增加 `proteinPer100g`、`fatPer100g`、`carbsPer100g`、`fiberPer100g`、`sugarPer100g`、`sodiumPer100g`
  - 新建 `computeMealNutrients(food, amount)`：按份量计算全部营养素
  - 新建 `formatNutrients(food)`：格式化展示完整营养素
  - 更新 `buildDietDisplay`：`recordSummary` 展示蛋白质/脂肪/碳水/纤维
  - 搜索结果列表每个食物展示完整营养素
  - 饮食记录表单展示选中食物的营养素
  - `本次添加`每条记录展示全部营养素
- **结果**：
  - 白米饭(100g) 蛋白质正确显示 2.6g
  - 今日记录汇总展示全部营养素
  - 113 个测试全绿

### 48. T12 收尾：Docker 配置与 CI

- **时间戳**：2026-05-27
- **任务编号**：T12（Docker + CI）
- **阶段**：容器化 / CI 配置
- **触发技能**：无
- **关键上下文**：课程要求 `docker-compose.yml`、CI 自动测试 + 构建镜像。
- **动作**：
  - 新建 `Dockerfile`：多阶段构建，builder 阶段 `npm run build:h5`，运行阶段 `npx tsx src/server.ts`
  - 新建 `docker-compose.yml`：app + MySQL 8.0，健康检查等待 MySQL 就绪
  - 新建 `.dockerignore`
  - 新建 `.github/workflows/ci.yml`：test job（typecheck + vitest）+ build-docker job
  - 修复 Dockerfile Alpine → Debian（Taro 原生依赖 `@tarojs/binding` 需要 glibc）
- **结果**：
  - 113 个测试通过，typecheck 通过，H5 构建成功
  - Docker Hub 被墙问题待解决（用户配置镜像加速器后验证）
- **学到的教训**：
  - Alpine 镜像体积小但缺 glibc，Node.js 原生 addon 多的项目用 Debian 更稳
  - `.dockerignore` 需保留 `config/`、`babel.config.cjs` 等构建所需文件

### 49. T12 CI 兼容性修复

- **时间戳**：2026-05-27
- **任务编号**：T12（CI 修复）
- **阶段**：调试 / CI 修复
- **触发技能**：`systematic-debugging`
- **关键上下文**：GitHub Actions CI test job 在 Ubuntu 上失败，本地 Windows 通过。
- **动作**：
  - 排查发现三个问题：
    1. `npm ci` 严格按 Windows lockfile 安装，Ubuntu 上平台特有依赖缺失
    2. `tests/lib/food-search.test.ts` mock 数据缺少 `FoodItem` 新增的 6 个营养素字段
    3. `addBodyMetric` / `addWorkoutCheckin` API 返回类型为 `unknown`，导致 plan.tsx / body.tsx 类型推断错误
  - 修复：`npm ci` → `npm install`、mock 补充字段、API 返回类型改为具体类型
  - 添加 `.swc/` `.tmp/` 到 `.gitignore`
- **结果**：CI 全部通过，typecheck + 113 tests + docker build 均成功。
- **学到的教训**：
  - `npm ci` 跨平台部署（Windows → Ubuntu）需改用 `npm install`
  - 类型修改必须同步更新全部测试 mock，否则本地通过但 CI 报错

### 50. T13 实现：README 与 REFLECTION

- **时间戳**：2026-05-31
- **任务编号**：T13（文档）
- **阶段**：文档收尾
- **触发技能**：无
- **关键上下文**：完成课程交付所需的 README.md 和 REFLECTION.md。
- **动作**：
  - 基于最新 master 创建 `feature/t13-docker-docs` worktree
  - 编写 `README.md`：项目简介、快速开始（Docker/本地/微信小程序）、端口与环境变量表、15 个 API 端点列表、目录结构树、测试命令、技术栈
  - 编写 `REFLECTION.md`：约 2200 字，覆盖 9 个课程要求问题
- **结果**：
  - README.md 和 REFLECTION.md 已合并到 master
  - 113 个测试通过，typecheck 通过
- **学到的教训**：
  - README 应该包含"一键运行"命令，降低验收门槛

### 51. 云部署：阿里云 ECS

- **时间戳**：2026-05-31
- **任务编号**：T13（云部署）
- **阶段**：部署上线
- **触发技能**：`systematic-debugging`
- **关键上下文**：课程要求提供截止日期前可访问的公网地址。
- **动作**：
  - 创建阿里云 ECS 实例（Ubuntu 22.04，1 核 2GB，按量付费）
  - 配置安全组放行 22/3000 端口
  - SSH 登录，安装 Docker + git
  - 配置 Docker 镜像加速器（daocloud / 1ms.run）
  - `git clone` 项目 → `docker-compose up -d` 启动 app + MySQL
  - 遇到 Docker Hub 拉镜像超时（阿里云默认镜像源被墙）→ 切换镜像源解决
  - `npm ci` 在 CI 报跨平台兼容 → 改为 `npm install`
- **结果**：
  - 公网地址 `http://47.116.36.135:3000` 可正常访问
  - 所有页面和 API 功能正常，MySQL 持久化存储
- **学到的教训**：
  - 阿里云 ECS 连 Docker Hub 需要配置国内镜像源
  - 按量付费模式适合学生项目测试，用完可销毁实例节省费用
  - 安全组规则需要手动放行自定义端口（如 3000），默认只开了 22/80

### 52. Open Design 技能库安装

- **时间戳**：2026-05-31
- **任务编号**：无（工具链扩展）
- **阶段**：工具链扩展
- **触发技能**：无
- **关键上下文**：用户希望安装 Open Design（120+ 设计技能）到 Claude Code。
- **动作**：
  - `git clone --depth 1` 克隆 Open Design 到 `~/.claude/plugins/open-design`
  - 创建 `.claude-plugin/marketplace.json` 注册为本地市场 `open-design-dev`
  - 通过 `claude plugin install open-design@open-design-dev` 全局安装
- **结果**：Open Design 120+ 技能已安装，重启 Claude Code 后可用。

### 53. 注册登录功能实现

- **时间戳**：2026-05-31
- **任务编号**：无（功能增强）
- **阶段**：实现 / TDD
- **触发技能**：`test-driven-development`、`systematic-debugging`
- **关键上下文**：项目尚无注册登录，SPEC 要求"需要登录与用户隔离"，当前写死 `demo-user` 不满足需求。
- **动作**：
  - 安装 `bcryptjs` 用于密码哈希
  - 更新 `users` 表 schema：添加 `password_hash` 字段，`name` 设为 UNIQUE
  - 新建 `src/auth/auth-service.ts`：注册（校验用户名/密码长度、查重、bcrypt 哈希）、登录（查用户、验密码）
  - 新建 `src/auth/user-repository.ts`：InMemoryUserRepository，支持按名称查找和创建
  - 新建 `src/api/auth.ts`：`POST /api/auth/register` + `POST /api/auth/login`
  - 更新 `app-context.ts`：添加 `userRepo`，预置管理员 demo 账号（admin / admin123）
  - 前端新建 `src/lib/auth-store.ts`：localStorage 存取用户信息
  - 更新 `src/lib/api.ts`：`getUserId()` 从 auth-store 读取真实 userId
  - 重写 `src/pages/me.tsx`：未登录显示登录/注册内联表单，已登录显示用户信息和退出按钮
  - 添加 `requireLogin()` 守卫：饮食、身体、计划页面的提交操作未登录时弹出 `alert("请先登录后再操作")`
  - 排查测试时发现 Docker 旧容器占用 3000 端口（`docker ps` 确认）→ `docker stop last-app-1` 解决
  - 排查 `server.ts` 路由顺序问题：静态文件 + SPA fallback 放在 API 路由之后导致 POST 请求被拦截 → 调整为 static → API → SPA fallback
- **结果**：
  - 注册登录功能完整可用，5 个测试场景全部通过（注册/重复注册/登录/错误密码/弱密码）
  - 数据按用户隔离：已登录用户的 API 请求带真实 userId，未登录操作被 `requireLogin` 阻断
  - 预置管理员账号 admin / admin123
  - 113 个测试全绿，typecheck 通过，H5 构建成功
- **学到的教训**：
  - `netstat` 查不到 Docker 容器的 LISTENING 状态，因为 Docker Desktop 在 Windows 上走 vpnkit 代理转发
  - 排查端口占用应优先 `docker ps`，再 `netstat`
  - Taro Input 不支持 `type="password"`，需用 `password` prop
  - 页面跳转在 Taro H5 SPA 中不可靠，内联表单比独立页面更可靠
  - `InMemoryUserRepository` 的 `store` 需为 `public` 才能从外部种子数据

### 54. 饮食记录持久化修复

- **时间戳**：2026-05-31
- **任务编号**：无（bug 修复）
- **阶段**：联调修复
- **触发技能**：`systematic-debugging`
- **关键上下文**：用户反馈刷新页面后添加的饮食记录消失，排查发现 `submitMeal` 只写入前端 React state，未调用后端 API。
- **动作**：
  - `lib/api.ts` 新增 `addMealRecord()` POST 函数
  - 重写 `submitMeal`：改为 `addMealRecord()` → 成功后重新 `getMealRecords()` 刷新数据
  - 删除本地 `meals` state 和 `localStats` useMemo（数据全部走后端）
  - 删除"本次添加"UI 区块（数据已在"今日记录"汇总中体现）
  - 将份量标签从"份量（每份 = 100g）"改为"克重（g）"
- **结果**：
  - 刷新页面后数据持久保留（内存模式下 server 重启前有效，MySQL 模式下永久持久化）
  - 后端 `factor = input.amount / 100` 自动换算，前端直接传克重即可
  - 113 个测试全绿
- **学到的教训**：
  - 前端 state 不等于持久化，数据写入必须走 API
  - 先提交数据再重新拉取，比本地计算 + 服务端计算两套逻辑更可靠

### 55. Tab Bar 样式修复

- **时间戳**：2026-05-31
- **任务编号**：无（UI 修复）
- **阶段**：UI 调试
- **触发技能**：`systematic-debugging`
- **关键上下文**：底部导航栏出现莫名其妙的方形框，排查发现是 Taro H5 使用 WeUI 渲染 tab bar，每个 tab 有一个空的 `<img class="weui-tabbar__icon">` 元素，浏览器为其渲染了默认边框。
- **动作**：
  - 尝试 CSS 覆盖失败（WeUI 使用 Shadow DOM，外部 CSS 无法穿透）
  - 尝试自定义 CustomTabBar（`custom: true`）+ `Taro.switchTab`→ 页面切换在 H5 SPA 模式下不可靠
  - 最终方案：恢复原生 tab bar + `.weui-tabbar__icon { display: none !important }` 隐藏空图标
  - 路由模式从 `browser` 切回 `hash`（`Taro.switchTab` 兼容性更好）
- **结果**：底部导航栏干净整洁，纯文字，无方框。
- **学到的教训**：
  - Taro H5 的 WeUI 组件用 Shadow DOM，CSS 穿透需精确命中内部 class
  - 浏览器 DevTools 元素选择器是定位 UI 问题的终极手段

### 56. 食物分类展示 + 拼音排序

- **时间戳**：2026-05-31
- **任务编号**：无（功能增强）
- **阶段**：功能增强
- **触发技能**：无
- **关键上下文**：用户希望饮食页面支持按拼音首字母分类全面展示食物，而非仅搜索模式。
- **动作**：
  - 第一版用硬编码 130+ 字符的拼音映射表 → 用户质疑"后续扩大食物库怎么办"
  - 安装 `pinyin-pro` 库，通过 `pinyin(name[0], { toneType: 'none' })` 动态计算拼音首字母，不再硬编码
  - 新增 `groupFoodsByLetter(foods)` 函数，返回按字母分组的食物列表
  - 饮食页面不搜索时显示 A-Z 分类列表（绿色字母标题 + 食物项），搜索时仍显示过滤结果
- **结果**：
  - 食物库扩展到任意数量均自动正确分组
  - `pinyin-pro` 体积约 10KB，H5 客户端正常加载
  - 113 测试全绿
- **学到的教训**：
  - 硬编码只在数据规模确定时可行，用户会比你先想到扩容场景
  - 中文拼音库选型要兼顾体积和准确性，`pinyin-pro` 是目前最佳选择

### 57. 饮食页面 UI 优化

- **时间戳**：2026-05-31
- **任务编号**：无（UI 优化）
- **阶段**：UI 优化
- **触发技能**：无
- **关键上下文**：用户提出两项优化：今日记录提到食物列表上方、支持展开查看每条记录详情。
- **动作**：
  - 将"今日记录"卡从页面底部移到 page header 下方
  - 新增 `showRecords` state 控制展开/折叠
  - 点击"今日记录"卡 → 展开显示当天每条饮食记录的详情（餐次、克重、热量、营养素、备注）
  - 点击"收起 ▲"折叠回去
  - `submitMeal` 提交成功后重新加载 `mealRecords` 并更新列表
- **结果**：
  - 今日记录始终在顶部可见，展开后直观展示每条记录
  - 空记录显示"暂无记录"
- **学到的教训**：
  - 汇总信息放在页面顶部比底部更符合用户阅读习惯

### 58. 自定义食物添加 / 编辑 / 删除 + 食物库扩充

- **时间戳**：2026-06-01
- **任务编号**：T6（扩展）
- **阶段**：功能增强
- **触发技能**：无
- **关键上下文**：用户发现饮食页面没有自定义食物入口，要求添加创建、编辑、删除功能，并扩充预置食物库。前端 API 层缺少 `addCustomFood`、`updateCustomFood`、`deleteCustomFood`，后端 `PUT /api/foods/:id`、`DELETE /api/foods/:id` 也未暴露。
- **动作**：
  - 后端 `FoodService` 新增 `updateCustomFood` 和 `deleteCustomFood` 方法，校验只能操作自己的自定义食物
  - `api/foods.ts` 新增 `PUT /:id` 和 `DELETE /:id` 路由
  - 前端 `lib/api.ts` 新增 `addCustomFood`、`updateCustomFood`、`deleteCustomFood`
  - `lib/food-search.ts` 的 `FoodItem` 接口增加 `sourceType`/`userId` 字段以区分预置/自定义
  - 饮食页面新增 "+ 添加自定义食物" 按钮和完整表单（名称 *、热量 *、蛋白质 *、脂肪 *、碳水 *、纤维、糖、钠）
  - 编辑功能：点击编辑后在食物下方展开内联编辑卡片（含字段标签），支持保存修改
  - 删除功能：点击删除后弹出浏览器 `confirm()` 确认，确认后删除
  - 自定义食物显示编辑/删除按钮，与预置食物区别展示
  - 预设食物库从 103 条扩充到 217 条（新增蔬菜、水果、坚果、肉类、水产、饮料、零食、调味品、地方小吃等 11 个类别）
  - 对应测试计数更新（100→216→217）
- **结果**：
  - `+ 记录`、`编辑`、`删除` 三个按钮同时显示在自定义食物旁
  - 编辑表单在食物下方内联展开，带标签
  - 删除有二次确认
  - 113 测试全绿，18 个测试文件全绿
- **学到的教训**：
  - 后端 API 可能早已支持，但前端 UI 缺失会让用户感觉功能不存在
  - Taro H5 中 `View` 渲染为 `<taro-view-core>` 自定义元素，`className`、`border`、`onClick` 均不可靠
  - 修改这类问题时用原生 HTML 标签（`<div>`/`<span>`）或 Taro CSS 类都各有问题，最终用内联样式 + `px` 大写跳过 pxtransform + `className` 混合方案

### 59. 首页 "饮水 3.2L" 假数据修复

- **时间戳**：2026-06-01
- **任务编号**：无（UI 修复）
- **阶段**：UI 修复
- **触发技能**：无
- **关键上下文**：用户发现首页今日概览中"饮水 3.2L"是硬编码假数据，要求替换为真实数据。
- **动作**：
  - `HomeDisplayData` 接口增加 `totalProtein` 字段
  - `buildHomeDisplay` 从 stats API 获取 `totalProtein` 并传入
  - 首页"饮水 3.2L"替换为真实蛋白质数据
- **结果**：首页显示真实的今日蛋白质摄入克数。
- **学到的教训**：假 placeholder 数据容易被误认为真实功能，应该在原型阶段就明确标注或直接使用真实数据。

### 60. 目标类型可修改

- **时间戳**：2026-06-01
- **任务编号**：无（功能增强）
- **阶段**：功能增强
- **触发技能**：无
- **关键上下文**：用户只能在注册时选择目标类型（减脂/维持/增肌），注册后无法修改。要求在"我的"页面支持修改。
- **动作**：
  - `InMemoryUserRepository` 新增 `findById` 和 `update` 方法
  - `IUserRepository` 接口同步扩展
  - `AuthService` 新增 `updateGoalType(userId, goalType)` 方法
  - `api/auth.ts` 新增 `PUT /goal` 路由
  - 前端 `me.tsx` 登录后个人信息卡片显示"修改"按钮，点击展开目标标签（减脂/维持/增肌）+ 取消/保存
- **结果**：用户登录后可在"我的"页面随时修改目标类型，修改后立即生效。
- **学到的教训**：注册时设定的用户属性应始终支持后续修改，这是基本 UX 要求。

### 61. MySQL 全数据持久化

- **时间戳**：2026-06-01
- **任务编号**：T12（扩展）
- **阶段**：基础设施
- **触发技能**：无
- **关键上下文**：用户发现每次重启服务账号就会丢失，需要重新注册。根因是应用路由层始终使用内存仓库，MySQL seed 只写了初始数据但不被路由层使用。用户本地有 MySQL 8.0（root 密码 `a13386980045`）。
- **动作**：
  - 创建本地数据库：`CREATE DATABASE health_app` + 用户 `health` / `health123`
  - 新增 `MysqlUserRepository` 实现用户 CRUD（findByName/findById/create/update）
  - 修复 ISO datetime 转 MySQL datetime 格式问题（`T` 和 `Z` 不兼容）
  - 新增 `src/repositories/mysql-repos.ts`：MysqlFoodRepository、MysqlMealRecordRepository、MysqlDailyMealSummaryRepository、MysqlWorkoutPlanRepository、MysqlWorkoutCheckinRepository、MysqlBodyMetricRepository
  - 所有 MySQL repo 使用 `pool.execute()` 与参数化查询
  - `app-context.ts` 改为接受可选的 `MysqlUserRepository` 参数，MySQL 可用时所有 repo 使用 MySQL 实现，不可用时回退内存
  - `server.ts`：MySQL seed 成功后自动创建 `MysqlUserRepository` 并传入 `beginNewAppContext`
  - `seed.ts`：种子数据增加 admin 用户（bcrypt 密码）和默认健身计划
  - 种子数据增加 workout plan 写入 workout_plans 表
- **结果**：
  - 重启服务后数据不丢失
  - MySQL 表数据量验证：users 3、foods 217、workout_plans 1
  - 113 测试全绿（内存模式不受影响）
- **学到的教训**：
  - 数据库 seed 和路由层数据源是两回事，seed 写 MySQL 不代表路由层用 MySQL
  - MySQL `TIMESTAMP` 列不接受 ISO 8601 格式（`T`/`Z`），需转换为 `YYYY-MM-DD HH:MM:SS`
  - ESM 中 `require()` 不可靠，静态 import 更安全

### 62. 按钮样式与取消按钮修复

- **时间戳**：2026-06-01
- **任务编号**：无（UI 修复）
- **阶段**：UI 调试
- **触发技能**：`systematic-debugging`
- **关键上下文**：
  - 按钮边框始终不显示：排查发现 Taro postcss-pxtransform 将 CSS 中的 `1px` 转为 `0.025rem`（约 0.4px 肉眼不可见），内联样式中的 `rpx` 浏览器不识别，`className` 在 `<taro-view-core>` 上不可靠
  - 顶部"添加自定义食物"取消按钮无效，但内联编辑取消按钮有效：根因是三元表达式 `{!showCustomForm ? A : B}` 在 Taro H5 中切换时干扰 click 事件，改为两个独立 `{!showCustomForm && A}` `{showCustomForm && B}` 块解决
  - 删除按钮无反应：confirm 弹窗使用 `window.confirm()` 兜底 + 传入 food 参数直接调用 `confirmDeleteFood(food)`
- **动作**：
  - CSS `.btn-action` 使用大写 `PX` 跳过 pxtransform 转换，border 设为 `2PX` 确保可见
  - 按钮文字统一 `font-size: 24rpx`，padding `6PX 16PX`
  - 顶部表单从三元改为 `&&` 块
  - 删除确认从内联卡片改为 `window.confirm()` 浏览器原生弹窗
  - 在 `handleDeleteFood` 中直接传入 food 参数
- **结果**：按钮边框可见（2px 绿色/红色），点击删除弹出 confirm，取消按钮正常收起表单，间距统一。
- **学到的教训**：
  - Taro H5 的 `<taro-view-core>` 自定义元素对 CSS class、border、onClick 的支持与原生 `<div>` 不同，需反复测试
  - `rpx` 在 CSS 文件中有效但在内联 style 中无效
  - 小写 `px` 会被 postcss-pxtransform 转换，大写 `PX` 可跳过
  - 三元表达式在 Taro 的条件渲染中不如 `&&` 可靠
  - `window.confirm()` 比自定义确认 UI 在 Taro H5 中更可靠

### 63. 训练计划分条目打卡

- **时间戳**：2026-06-03
- **任务编号**：T8（扩展）
- **阶段**：功能增强
- **触发技能**：`systematic-debugging`
- **关键上下文**：用户要求训练计划的每个动作可以独立打卡完成，而不是整天的"一刀切"。需要修改 WorkoutCheckin 数据模型、后端服务、MySQL 仓库和前端 UI。
- **动作**：
  - `WorkoutCheckin` 类型新增 `completedExercises: string[]` 字段
  - MySQL `workout_checkins` 表新增 `completed_exercises JSON` 列
  - `MysqlWorkoutCheckinRepository` 新增 `update` 方法，`rowToCheckin` 修复日期格式化（`Date` → `ISO string`）
  - `WorkoutCheckinService.createCheckin` 改为 upsert 模式：有当日记录则 toggle 指定 exercise，无则创建新记录
  - 移除 plan 归属校验（计划为共享模板，不应校验 `plan.userId !== userId`）
  - 前端 `addWorkoutCheckin` 新增 `exerciseName` 参数
  - 计划页今日训练卡片改造：每个动作前显示 22×22px 复选框，点击 toggle 完成状态
  - 完成状态通过 `completedToday` state 管理，直接从 API 返回值设置
  - 按钮样式全用 `px` 单位（避免 Taro 运行时转换 `rpx` 失败导致复选框尺寸为 0）
  - 添加"已完成"/"已取消"反馈提示（绿色卡片，1.5 秒自动消失）
- **踩坑与修复**：
  - `MysqlWorkoutCheckinRepository` 缺少 `update` 方法导致第二次打卡报 500 错误 → 补充 `update` SQL
  - `rowToCheckin` 中 `String(Date).slice(0,10)` 返回 `"Tue Jun 02"` 而非 `"2026-06-02"` → 改用 `Date.toISOString().slice(0,10)`
  - `useEffect` 监听 `checkins` 变化时重新提取 `completedExercises`，覆盖了 `toggleExercise` 刚设置的正确值 → 移除 `useEffect`，改为 `loadPlan` 中直接提取
  - 复选框 `rpx` 在内联样式中被 Taro 运行时忽略导致宽高为 0 → 全部改用 `px`
  - Plan 归属校验阻止真实用户查询打卡记录（旧计划 `userId: 'system'`）→ 移除校验
- **结果**：
  - 每个训练动作可独立勾选 ✓，刷新不丢失
  - 勾选显示绿色背景 + 白色 ✓ + 文字删除线，取消恢复原状
  - 操作反馈即时显示"已完成"/"已取消"
- **学到的教训**：
  - Taro H5 的内联 `rpx` 是持续踩坑点——复选框的 `width/height: '36rpx'` 在浏览器里不生效，`px` 则直接可靠
  - React `useEffect` 对数组状态的二次计算很容易产生"设置→覆盖"的竞态，直接在一次异步回调中完成所有状态更新更安全
  - MySQL JSON 列配合 `mysql2` 时需注意返回值是字符串还是已解析对象，做好兼容判断
  - 共享模板（plan）不应校验 `userId` 归属，避免 multi-tenant 场景下 404

### 64. 活动量选择 + 饮食计划热量公式联动

- **时间戳**：2026-06-03
- **任务编号**：T10（扩展）
- **阶段**：功能增强
- **触发技能**：`brainstorming`
- **关键上下文**：热量计算一直用固定活动系数（久坐 1.2），需要让用户选择活动量来影响 TDEE 计算，同时传递给 AI 调整饮食计划。
- **动作**：
  - `calorie-calc.ts`：新增 `ActivityLevel` 类型、`ACTIVITY_OPTIONS` 常量表和 `getActivityFactor()` 函数，`calcTDEE()` 和 `calcDailyTarget()` 接受 `activityLevel` 参数
  - `ai-client.ts`：`generateDiet()` 接受 `activityLevel`，计算参考热量并附带活动量标签（如"中度活动（每周3-5天），系数1.55"）传给 AI prompt
  - `workout-plan-service.ts`：`generateDietOnly()` 接受 `activityLevel` 透传
  - `api/workout-plans.ts`：从 `req.body.activityLevel` 读取活动量
  - 计划页：点击"生成饮食计划"→ 弹出 5 级活动量卡片（久坐不动/轻度/中度/高度/运动员），每项显示系数和说明，选中后点"开始生成"
- **结果**：
  - 用户可选择活动量（默认 moderate），TDEE 按系数调整（1.2 → 1.9）
  - AI 收到活动量信息后相应调整蛋白质和碳水比例
- **学到的教训**：
  - 活动量级别的天数描述要避免重叠（light 1-2、moderate 3-5）
  - 选择 + 确认按钮的 UX 比点击即触发更好，避免误触

### 65. 用户体重/身高同步 + 注册必填 + 身高必填

- **时间戳**：2026-06-03 ~ 2026-06-06
- **任务编号**：T2（扩展）
- **阶段**：功能增强
- **触发技能**：无
- **关键上下文**：用户信息中缺少体重和身高，注册时这些关键字段也不是必填。需要在个人信息、注册、身体记录之间实现数据联动。
- **动作**：
  - `User`/`UserRow` 新增 `weight`、`height` 字段（nullable），MySQL `users` 表 ALTER 加列
  - `AuthService.register()` 新增 profile 参数，校验 gender/age/weight/height 必填
  - `MysqlUserRepository` 增/删/改/查全部更新支持 weight/height
  - 注册页新增性别、年龄、体重、身高四个必填表单项
  - 身体记录 API 新增自动同步：`POST /body-metrics` 成功后调用 `AuthService.updateProfile()` 写入体重身高
  - 新增 `GET /api/auth/profile` + `AuthService.getProfile()` 让前端拉取最新个人信息
  - "我的"页面改为启动时从 API 拉取最新数据（不再只依赖 localStorage 缓存）
  - 编辑个人信息页新增体重/身高输入框
  - 身体记录身高从选填改为必填，后端校验同步
- **结果**：
  - 注册时必须填写完整的身体数据，AI 计划可直接使用
  - 身体页面录入后自动同步到"我的"页面
  - "我的"页面每次加载从服务器拉取最新数据
- **学到的教训**：
  - localStorage 缓存 ≠ 服务端数据，关键数据必须从 API 拉取
  - 静默 `catch(() => {})` 会掩盖错误——之前 auto-sync 失败就是因为 `userRepo.update()` 类型不匹配被 swallow
  - 注册页加字段时要注意排版——体重/身高并排节省空间

### 66. 主页热量目标切换到 AI 饮食计划

- **时间戳**：2026-06-06
- **任务编号**：T10（扩展）
- **阶段**：功能调整
- **触发技能**：无
- **关键上下文**：主页热量目标和饮食计划目标来源不一致——一个用服务端 Mifflin-St Jeor 公式（固定 sedentary），一个用 AI 自己算的值。
- **动作**：
  - `ai-client.ts` `generateDiet()` 停止预计算热量传给 AI，改为把 Mifflin-St Jeor 公式和活动系数写入 prompt，让 AI 自己算 `dailyCalories`
  - 主页移除 `/api/calorie-target` 调用，热量目标直接读 AI 饮食计划的 `dailyCalories`
  - 热量目标卡片简化为"目标 kcal vs 已摄入 kcal + 进度条"
  - 未生成饮食计划时显示引导文案而非公式兜底
- **结果**：
  - 热量目标与 AI 饮食计划一致，不再有两个不同数字
  - AI 根据公式自行计算，灵活性更高
- **学到的教训**：
  - 两套计算逻辑（公式 + AI）容易产生不一致——应该选其一作为单一数据源
  - 传给 AI 的 prompt 里放公式比放具体数字好——AI 会用公式重新算一遍，内部一致性更强

### 67. 登录状态检查 + 入口页调整 + 头像删除

- **时间戳**：2026-06-03 ~ 2026-06-06
- **任务编号**：T11/T12（扩展）
- **阶段**：UI 修复 + 安全
- **触发技能**：无
- **关键上下文**：
  - 未登录时首页/计划页/身体页显示"数据加载失败"而非引导登录
  - 训练计划和饮食计划 API 未校验登录状态，未登录也能看到数据
  - 入口页是首页，用户希望先看到"我的"页面引导登录
- **动作**：
  - 首页、计划页、身体页都加了 `isLoggedIn()` 检查，未登录显示"请先登录"
  - `GET /workout-plans/current` 和 `GET /workout-plans/diet-current` 新增 `x-user-id` 校验
  - `app.config.ts` 新增 `entryPagePath: 'pages/me'`，开机进入"我的"页面
  - 删除"我的"页面用户名旁的头像字母圆圈（用户觉得多余）
- **结果**：
  - 未登录用户体验一致——所有页面引导去登录
  - 已登录用户数据不会泄露给未登录访问者
- **学到的教训**：
  - API 层的登录校验必须和前端 UI 的登录引导同步做，缺一不可

### 68. Webpack 文件名内容哈希 + 浏览器缓存消除

- **时间戳**：2026-06-06
- **任务编号**：T13（扩展）
- **阶段**：基础设施
- **触发技能**：`systematic-debugging`
- **关键上下文**：每次代码变更后刷新浏览器仍显示旧版，需要 Ctrl+Shift+R 强制刷新。根因是 Taro 编译输出的 JS 文件名固定（如 `chunk/837.js`），浏览器按 URL 缓存。
- **动作**：
  - `config/index.ts` h5 配置中加入 `webpackChain`，设置 `output.filename` 和 `output.chunkFilename` 为 `[name].[contenthash:8].js`
  - 验证构建产物中 `index.html` 正确引用哈希文件名
- **结果**：
  - 每次构建后 JS 文件名带 8 位哈希（如 `chunk/837.3d03168f.js`）
  - 代码变更后浏览器自动拉取新文件，无需手动强制刷新
- **学到的教训**：
  - 内容哈希是最彻底的缓存破坏方案，比 `Cache-Control: no-cache` 更可靠
  - Taro 4.2 的 `webpackChain` 配置可以直接修改底层 webpack 输出

### 69. 移除默认训练计划种子数据

- **时间戳**：2026-06-06
- **任务编号**：T10（扩展）
- **阶段**：数据清理
- **触发技能**：无
- **关键上下文**：用户未生成任何训练计划，但计划页显示了"新手入门训练计划"。这是 seed 预置的 `wp-1` 默认计划。
- **动作**：
  - `db/seed.ts` 删除 workout plan seed 代码块
  - `app-context.ts` 删除内存模式的默认计划 seed
  - MySQL 执行 `DELETE FROM workout_plans`
- **结果**：无计划时计划页为空，需用户主动点击"生成训练计划"
- **学到的教训**：种子数据应该只放"系统运行必不可少"的内容（如 admin 用户、食物库），默认计划属于"用户自行生成"的范畴

### 70. REFLECTION.md + README 更新 + SPEC 修正

- **时间戳**：2026-06-06
- **任务编号**：项目交付
- **阶段**：文档收尾
- **触发技能**：无
- **关键上下文**：项目进入收尾阶段，需要对照课程要求检查交付物完整性，补写反思报告。
- **动作**：
  - 对照 `AI4SE_Final_Project0518.md` 检查交付物清单，发现 REFLECTION.md 缺失
  - 从 `last-t13` worktree 复制旧版 REFLECTION.md，基于当前项目状态全面更新（9 个反思问题全部覆盖）
  - README.md 全面重写：新增功能特性、全部 25 个 API 端点、DeepSeek 配置说明、更新目录结构
  - SPEC.md 修复 §1.3 章节号重复（两个 1.3 → 1.3/1.4）
  - PLAN.md 和 SPEC.md 同步了活动量、注册必填、热量来源等后期变更
- **结果**：
  - 全部 7 个交付物文件齐备
  - 72 个 commit，113 个测试，云部署可访问
- **学到的教训**：
  - 文档应随代码同步更新——积压到收尾阶段批量修改工作量大且容易遗漏
  - 对照 rubric 逐项自查是发现遗漏最高效的方式
